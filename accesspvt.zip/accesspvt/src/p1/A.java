package p1;
//private
public class A {
	private void display() {
		System.out.println("private access modifier");
	}
 public static void main(String args[]) {
	 A obj= new A();
	 obj.display();
 }
}
