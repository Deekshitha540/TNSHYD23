package p1;

public class A {
	public void display() {
		System.out.println("public access specifier");
	}
	}

