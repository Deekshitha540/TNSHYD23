package com.day3;

public class F {
	int d=50;
 public static void main(String args[]) {
	 E f = new E() ;
	 System.out.println(f.c);
	 
 }
 }
