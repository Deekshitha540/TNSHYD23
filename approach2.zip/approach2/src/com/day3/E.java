package com.day3;

public class E {
	int b=30;
	static int c=40;
}

