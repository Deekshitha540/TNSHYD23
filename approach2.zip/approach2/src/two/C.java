package two;
//normal
public class C {
	int b=30;
	static int c=40;

}
