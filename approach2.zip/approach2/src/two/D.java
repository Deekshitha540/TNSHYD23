package two;

public class D {
	public static void main(String args[]) {
		C a1= new C();
		System.out.println(a1.b);
		System.out.println(C.c);
	}

}
