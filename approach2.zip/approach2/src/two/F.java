package two;

public class F {

	public static void main(String[] args) {
		E e= new E();
		System.out.println(e.b);
		System.out.println(e.display());
		E.display1();
		

	}

}
