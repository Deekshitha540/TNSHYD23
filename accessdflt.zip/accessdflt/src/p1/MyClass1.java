package p1;

public class MyClass1 {
	void display() {
		System.out.println("default access modifier");
	}
	public static void main(String args[]) {
		MyClass1 obj =new MyClass1();
		obj.display();
	}

}
