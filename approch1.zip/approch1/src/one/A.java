package one;

public class A {
	int b=30;
	static int c=40;
	public static void main(String[] args) {
		int d=50;
		A b1= new A();
		System.out.println(b1.b);
		System.out.println(A.c);
		System.out.println(d);

	}

}
