package one;
//method
public class B {
	int b=30;
	static int c=40;
	int display() {
		return 10;
	}
		static void display1() {
			System.out.println("10");
		}
		

	public static void main(String[] args) {
		B b1= new B();
		System.out.println(b1.b);
		System.out.println(b1.display());
	    B. display1();
		

	}

}
